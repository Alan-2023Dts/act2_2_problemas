using System.Globalization;

namespace Act_1_Figuras;

public sealed class MainForm : Form
{
    private readonly ComboBox figuraComboBox = new();
    private readonly Label primerValorLabel = new();
    private readonly Label segundoValorLabel = new();
    private readonly TextBox primerValorTextBox = new();
    private readonly TextBox segundoValorTextBox = new();
    private readonly Button calcularButton = new();
    private readonly Label resultadoLabel = new();

    public MainForm()
    {
        Text = "Cálculo de áreas";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(420, 320);
        Font = new Font("Segoe UI", 10F);

        var tituloLabel = new Label
        {
            Text = "Calculadora de áreas",
            AutoSize = true,
            Font = new Font(Font.FontFamily, 16F, FontStyle.Bold),
            Location = new Point(20, 20)
        };

        var subtituloLabel = new Label
        {
            Text = "Usa una interfaz común para distintas figuras",
            AutoSize = true,
            Location = new Point(20, 55)
        };

        var figuraLabel = new Label
        {
            Text = "Figura",
            AutoSize = true,
            Location = new Point(20, 95)
        };

        figuraComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
        figuraComboBox.Items.AddRange(new object[] { "Rectángulo", "Triángulo", "Círculo" });
        figuraComboBox.SelectedIndex = 0;
        figuraComboBox.Location = new Point(20, 120);
        figuraComboBox.Width = 160;
        figuraComboBox.SelectedIndexChanged += (_, _) => ActualizarCampos();

        primerValorLabel.Location = new Point(20, 165);
        primerValorLabel.AutoSize = true;

        primerValorTextBox.Location = new Point(20, 190);
        primerValorTextBox.Width = 160;

        segundoValorLabel.Location = new Point(210, 165);
        segundoValorLabel.AutoSize = true;

        segundoValorTextBox.Location = new Point(210, 190);
        segundoValorTextBox.Width = 160;

        calcularButton.Text = "Calcular área";
        calcularButton.Location = new Point(20, 235);
        calcularButton.Width = 160;
        calcularButton.Click += (_, _) => CalcularArea();

        resultadoLabel.AutoSize = true;
        resultadoLabel.Location = new Point(210, 240);
        resultadoLabel.Font = new Font(Font.FontFamily, 10F, FontStyle.Bold);

        Controls.AddRange(new Control[]
        {
            tituloLabel,
            subtituloLabel,
            figuraLabel,
            figuraComboBox,
            primerValorLabel,
            primerValorTextBox,
            segundoValorLabel,
            segundoValorTextBox,
            calcularButton,
            resultadoLabel
        });

        ActualizarCampos();
    }

    private void ActualizarCampos()
    {
        var figuraSeleccionada = figuraComboBox.SelectedItem?.ToString() ?? string.Empty;

        if (figuraSeleccionada == "Círculo")
        {
            primerValorLabel.Text = "Radio";
            segundoValorLabel.Text = string.Empty;
            segundoValorLabel.Visible = false;
            segundoValorTextBox.Visible = false;
        }
        else
        {
            primerValorLabel.Text = figuraSeleccionada == "Triángulo" ? "Base" : "Base";
            segundoValorLabel.Text = "Altura";
            segundoValorLabel.Visible = true;
            segundoValorTextBox.Visible = true;
        }

        primerValorTextBox.Text = string.Empty;
        segundoValorTextBox.Text = string.Empty;
        resultadoLabel.Text = string.Empty;
    }

    private void CalcularArea()
    {
        if (!TryReadPositiveDouble(primerValorTextBox.Text, out var primerValor))
        {
            MostrarError("Ingresa un valor válido y mayor que cero.");
            return;
        }

        var figuraSeleccionada = figuraComboBox.SelectedItem?.ToString() ?? string.Empty;
        IFigura figura;

        if (figuraSeleccionada == "Círculo")
        {
            figura = new Circulo(primerValor);
        }
        else
        {
            if (!TryReadPositiveDouble(segundoValorTextBox.Text, out var segundoValor))
            {
                MostrarError("Ingresa un segundo valor válido y mayor que cero.");
                return;
            }

            figura = figuraSeleccionada == "Triángulo"
                ? new Triangulo(primerValor, segundoValor)
                : new Rectangulo(primerValor, segundoValor);
        }

        resultadoLabel.Text = $"Área: {figura.CalcularArea().ToString("N2", CultureInfo.CurrentCulture)}";
    }

    private static bool TryReadPositiveDouble(string text, out double value)
    {
        return double.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out value) && value > 0;
    }

    private void MostrarError(string message)
    {
        MessageBox.Show(this, message, "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}